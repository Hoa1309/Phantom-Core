// game.js — browser-playable Asteroid Dodge 3D demo (Three.js)
import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.161.0/build/three.module.js';

const canvas = document.querySelector('#game');
const scoreEl = document.querySelector('#score');
const livesEl = document.querySelector('#lives');
const messageEl = document.querySelector('#message');
const startBtn = document.querySelector('#startBtn');

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x050817);
scene.fog = new THREE.Fog(0x050817, 18, 65);

const camera = new THREE.PerspectiveCamera(58, 1, 0.1, 120);
camera.position.set(0, 12, -17);
camera.lookAt(0, 0, 4);

const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

scene.add(new THREE.HemisphereLight(0x8fbaff, 0x151126, 2.1));
const keyLight = new THREE.DirectionalLight(0xffffff, 2.2);
keyLight.position.set(-5, 12, -4);
keyLight.castShadow = true;
scene.add(keyLight);

const floor = new THREE.Mesh(
  new THREE.PlaneGeometry(20, 90),
  new THREE.MeshStandardMaterial({ color: 0x101a37, metalness: 0.25, roughness: 0.72 })
);
floor.rotation.x = -Math.PI / 2;
floor.position.set(0, -0.6, 15);
floor.receiveShadow = true;
scene.add(floor);

// Glowing lane lines and stars.
const lineMat = new THREE.MeshBasicMaterial({ color: 0x1b75c9 });
for (const x of [-4.5, 0, 4.5]) {
  const line = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.02, 85), lineMat);
  line.position.set(x, -0.57, 15);
  scene.add(line);
}
const starPositions = [];
for (let i = 0; i < 450; i++) {
  starPositions.push((Math.random() - 0.5) * 100, Math.random() * 35 + 2, Math.random() * 100 - 25);
}
const starGeo = new THREE.BufferGeometry();
starGeo.setAttribute('position', new THREE.Float32BufferAttribute(starPositions, 3));
scene.add(new THREE.Points(starGeo, new THREE.PointsMaterial({ color: 0xa8cfff, size: 0.13 })));

function makeShip() {
  const group = new THREE.Group();
  const body = new THREE.Mesh(
    new THREE.ConeGeometry(0.72, 2.25, 5),
    new THREE.MeshStandardMaterial({ color: 0x35c8ff, emissive: 0x064f80, metalness: 0.65, roughness: 0.25 })
  );
  body.rotation.x = -Math.PI / 2;
  body.position.y = 0.2;
  body.castShadow = true;
  group.add(body);
  const wingMat = new THREE.MeshStandardMaterial({ color: 0x1676ff, metalness: 0.4, roughness: 0.3 });
  for (const side of [-1, 1]) {
    const wing = new THREE.Mesh(new THREE.BoxGeometry(0.95, 0.12, 0.8), wingMat);
    wing.position.set(side * 0.75, 0.12, 0.25);
    wing.rotation.y = side * -0.18;
    group.add(wing);
  }
  const glow = new THREE.PointLight(0x16aaff, 2, 5);
  glow.position.set(0, 0.3, -1.2);
  group.add(glow);
  group.position.set(0, 0.25, -5);
  scene.add(group);
  return group;
}
const ship = makeShip();

const keys = new Set();
const asteroids = [];
let score = 0, lives = 3, running = false, lastTime = 0, spawnTimer = 0;
let best = Number(localStorage.getItem('asteroidBest') || 0);
let animationId = 0;

function updateHud() {
  scoreEl.textContent = `SCORE ${Math.floor(score)}`;
  livesEl.textContent = `LIVES ${'♥'.repeat(Math.max(0, lives))}`;
}
function spawnAsteroid() {
  const rock = new THREE.Mesh(
    new THREE.IcosahedronGeometry(0.55 + Math.random() * 0.65, 1),
    new THREE.MeshStandardMaterial({
      color: new THREE.Color().setHSL(0.06 + Math.random() * 0.06, 0.3, 0.35 + Math.random() * 0.15),
      roughness: 0.95, metalness: 0.08
    })
  );
  rock.position.set((Math.random() - 0.5) * 12, 0.1 + Math.random() * 0.5, 23 + Math.random() * 12);
  rock.rotation.set(Math.random() * 3, Math.random() * 3, Math.random() * 3);
  rock.userData = { radius: rock.geometry.parameters.radius || 0.9, speed: 8 + Math.min(score / 100, 12) + Math.random() * 4, spin: (Math.random() - 0.5) * 2 };
  rock.castShadow = true;
  scene.add(rock);
  asteroids.push(rock);
}
function endGame() {
  running = false;
  best = Math.max(best, Math.floor(score));
  localStorage.setItem('asteroidBest', String(best));
  messageEl.innerHTML = `GAME OVER<br><small>Score: ${Math.floor(score)} · Best: ${best}</small><br><small>Nhấn CHƠI LẠI để thử tiếp</small>`;
  messageEl.classList.remove('hidden');
  startBtn.textContent = 'CHƠI LẠI';
}
function startGame() {
  for (const rock of asteroids) scene.remove(rock);
  asteroids.length = 0;
  ship.position.set(0, 0.25, -5);
  score = 0; lives = 3; spawnTimer = 0;
  running = true;
  lastTime = performance.now();
  messageEl.classList.add('hidden');
  startBtn.textContent = 'ĐANG CHƠI';
  updateHud();
}
function resize() {
  const w = canvas.clientWidth || 800, h = canvas.clientHeight || 500;
  renderer.setSize(w, h, false);
  camera.aspect = w / h;
  camera.updateProjectionMatrix();
}
window.addEventListener('resize', resize);
resize();

window.addEventListener('keydown', e => {
  if (['ArrowLeft','ArrowRight','ArrowUp','ArrowDown',' '].includes(e.key)) e.preventDefault();
  keys.add(e.key.toLowerCase());
  if ((e.key === 'Enter' || e.key.toLowerCase() === 'r') && !running) startGame();
});
window.addEventListener('keyup', e => keys.delete(e.key.toLowerCase()));

document.querySelectorAll('[data-control]').forEach(btn => {
  const key = btn.dataset.control;
  const down = e => { e.preventDefault(); keys.add(key); btn.classList.add('pressed'); };
  const up = e => { e.preventDefault(); keys.delete(key); btn.classList.remove('pressed'); };
  btn.addEventListener('pointerdown', down);
  ['pointerup','pointercancel','pointerleave'].forEach(ev => btn.addEventListener(ev, up));
});
startBtn.addEventListener('click', () => { if (!running) startGame(); });

function animate(now) {
  animationId = requestAnimationFrame(animate);
  const dt = Math.min((now - (lastTime || now)) / 1000, 0.04);
  lastTime = now;

  if (running) {
    score += dt * 10;
    const speed = 8.5;
    let dx = 0, dz = 0;
    if (keys.has('arrowleft') || keys.has('a') || keys.has('left')) dx -= 1;
    if (keys.has('arrowright') || keys.has('d') || keys.has('right')) dx += 1;
    if (keys.has('arrowup') || keys.has('w') || keys.has('up')) dz += 1;
    if (keys.has('arrowdown') || keys.has('s') || keys.has('down')) dz -= 1;
    ship.position.x = THREE.MathUtils.clamp(ship.position.x + dx * speed * dt, -8.5, 8.5);
    ship.position.z = THREE.MathUtils.clamp(ship.position.z + dz * speed * dt, -9, 2);
    ship.rotation.z = THREE.MathUtils.lerp(ship.rotation.z, -dx * 0.28, 0.15);
    ship.rotation.x = THREE.MathUtils.lerp(ship.rotation.x, dz * 0.08, 0.15);

    spawnTimer += dt;
    const interval = Math.max(0.28, 0.82 - score / 900);
    if (spawnTimer >= interval) { spawnTimer = 0; spawnAsteroid(); }

    for (let i = asteroids.length - 1; i >= 0; i--) {
      const rock = asteroids[i];
      rock.position.z -= rock.userData.speed * dt;
      rock.rotation.x += rock.userData.spin * dt;
      rock.rotation.y += rock.userData.spin * 0.8 * dt;
      const dxRock = rock.position.x - ship.position.x;
      const dzRock = rock.position.z - ship.position.z;
      if (Math.hypot(dxRock, dzRock) < 1.15) {
        scene.remove(rock); asteroids.splice(i, 1);
        lives--;
        if (lives <= 0) { updateHud(); endGame(); break; }
      } else if (rock.position.z < -15) {
        scene.remove(rock); asteroids.splice(i, 1);
        score += 5;
      }
    }
    updateHud();
  }
  renderer.render(scene, camera);
}
animate(0);
