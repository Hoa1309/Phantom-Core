// AsteroidCore.cpp
// C++ helper logic for Asteroid Dodge 3D.
// Optional native library / WebAssembly source. The browser demo uses game.js directly.
#include <algorithm>
#include <cmath>

#if defined(_WIN32)
#define ASTRO_API __declspec(dllexport)
#else
#define ASTRO_API
#endif

extern "C" {

// Clamp player movement to a horizontal range.
ASTRO_API float Astro_ClampLane(float x, float minX, float maxX) {
    return std::max(minX, std::min(x, maxX));
}

// Calculate score gained for surviving deltaTime seconds.
ASTRO_API int Astro_ScoreForTime(float deltaTime, float multiplier) {
    if (deltaTime < 0.0f) deltaTime = 0.0f;
    if (multiplier < 0.0f) multiplier = 0.0f;
    return static_cast<int>(std::floor(deltaTime * multiplier));
}

// Return 1 when two circles overlap in the X/Z plane, otherwise 0.
ASTRO_API int Astro_CircleCollision(float ax, float az, float ar,
                                    float bx, float bz, float br) {
    const float dx = ax - bx;
    const float dz = az - bz;
    const float radius = std::max(0.0f, ar) + std::max(0.0f, br);
    return (dx * dx + dz * dz) <= (radius * radius) ? 1 : 0;
}

}
