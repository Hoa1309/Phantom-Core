// GameManager.cs
// Optional Unity C# version of the game manager.
// Create a Unity 3D project, add this file to Assets/Scripts, then attach it
// to an empty GameObject. It creates a simple player and falling asteroids.
using UnityEngine;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public float playerSpeed = 8f;
    public float asteroidSpawnEvery = 0.8f;
    public float asteroidSpeed = 10f;
    public int score;
    public int lives = 3;

    private Transform player;
    private float spawnTimer;
    private bool gameOver;
    private Text hud;

    void Start()
    {
        // Simple runtime-created player.
        GameObject ship = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        ship.name = "PlayerShip";
        ship.transform.position = new Vector3(0, 0.7f, -5);
        ship.transform.localScale = new Vector3(0.8f, 0.5f, 1.4f);
        ship.GetComponent<Renderer>().material.color = new Color(0.15f, 0.75f, 1f);
        player = ship.transform;

        // Camera and light setup.
        Camera.main.transform.position = new Vector3(0, 12, -13);
        Camera.main.transform.rotation = Quaternion.Euler(55, 0, 0);
        if (FindObjectOfType<Light>() == null)
        {
            var lightObject = new GameObject("Directional Light");
            var light = lightObject.AddComponent<Light>();
            light.type = LightType.Directional;
            light.transform.rotation = Quaternion.Euler(50, -30, 0);
        }

        GameObject floor = GameObject.CreatePrimitive(PrimitiveType.Plane);
        floor.name = "SpaceFloor";
        floor.transform.position = new Vector3(0, 0, 2);
        floor.transform.localScale = new Vector3(2, 1, 2);
        floor.GetComponent<Renderer>().material.color = new Color(0.025f, 0.035f, 0.09f);

        CreateHud();
    }

    void Update()
    {
        if (gameOver)
        {
            if (Input.GetKeyDown(KeyCode.R)) RestartGame();
            return;
        }

        float moveX = Input.GetAxisRaw("Horizontal");
        float moveZ = Input.GetAxisRaw("Vertical");
        Vector3 move = new Vector3(moveX, 0, moveZ).normalized;
        player.position += move * playerSpeed * Time.deltaTime;
        player.position = new Vector3(
            Mathf.Clamp(player.position.x, -7f, 7f),
            0.7f,
            Mathf.Clamp(player.position.z, -7f, 4f)
        );

        spawnTimer += Time.deltaTime;
        if (spawnTimer >= asteroidSpawnEvery)
        {
            spawnTimer = 0;
            SpawnAsteroid();
        }

        score += Mathf.RoundToInt(Time.deltaTime * 10);
        UpdateHud();
    }

    void SpawnAsteroid()
    {
        GameObject rock = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        rock.name = "Asteroid";
        float x = Random.Range(-7f, 7f);
        rock.transform.position = new Vector3(x, 0.7f, Random.Range(10f, 16f));
        float size = Random.Range(0.6f, 1.4f);
        rock.transform.localScale = Vector3.one * size;
        rock.GetComponent<Renderer>().material.color = new Color(0.55f, 0.42f, 0.35f);
        var asteroid = rock.AddComponent<AsteroidMover>();
        asteroid.speed = asteroidSpeed;
        asteroid.manager = this;
    }

    public void HitAsteroid(GameObject asteroid)
    {
        if (gameOver) return;
        Destroy(asteroid);
        lives--;
        if (lives <= 0)
        {
            gameOver = true;
            UpdateHud();
        }
    }

    void CreateHud()
    {
        var canvasObject = new GameObject("HUD");
        var canvas = canvasObject.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvasObject.AddComponent<CanvasScaler>();
        canvasObject.AddComponent<GraphicRaycaster>();

        var textObject = new GameObject("ScoreText");
        textObject.transform.SetParent(canvas.transform, false);
        hud = textObject.AddComponent<Text>();
        hud.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        hud.fontSize = 24;
        hud.color = Color.white;
        hud.alignment = TextAnchor.UpperLeft;
        var rect = hud.rectTransform;
        rect.anchorMin = new Vector2(0, 1);
        rect.anchorMax = new Vector2(0, 1);
        rect.pivot = new Vector2(0, 1);
        rect.anchoredPosition = new Vector2(20, -20);
        rect.sizeDelta = new Vector2(500, 100);
        UpdateHud();
    }

    void UpdateHud()
    {
        if (hud == null) return;
        hud.text = gameOver
            ? $"GAME OVER\\nScore: {score}\\nPress R to restart"
            : $"ASTEROID DODGE 3D   Score: {score}   Lives: {lives}\\nMove: WASD / Arrow Keys";
    }

    void RestartGame()
    {
        foreach (var rock in GameObject.FindGameObjectsWithTag("Untagged"))
            if (rock.name == "Asteroid") Destroy(rock);
        lives = 3;
        score = 0;
        spawnTimer = 0;
        gameOver = false;
        player.position = new Vector3(0, 0.7f, -5);
        UpdateHud();
    }
}

public class AsteroidMover : MonoBehaviour
{
    public float speed = 10f;
    public GameManager manager;

    void Update()
    {
        transform.position += Vector3.back * speed * Time.deltaTime;
        transform.Rotate(35f * Time.deltaTime, 60f * Time.deltaTime, 20f * Time.deltaTime);

        if (manager != null && Vector3.Distance(transform.position, manager.transform.position) < 0.01f)
            return;

        GameObject player = GameObject.Find("PlayerShip");
        if (player != null && Vector3.Distance(transform.position, player.transform.position) < 1.1f)
        {
            if (manager != null) manager.HitAsteroid(gameObject);
            else Destroy(gameObject);
            return;
        }

        if (transform.position.z < -12f) Destroy(gameObject);
    }
}
