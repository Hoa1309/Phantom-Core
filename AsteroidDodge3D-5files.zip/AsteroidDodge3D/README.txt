ASTEROID DODGE 3D — 4 file source pack

Files requested:
- AsteroidCore.cpp: optional C++ helper functions.
- GameManager.cs: optional Unity implementation.
- game.js: playable browser 3D game using Three.js.
- index.html: browser page.
Additional style.css is required by index.html.

PLAY IN BROWSER:
1. Put all files in the same folder.
2. Because game.js uses ES modules, serve the folder via a local web server (don't double-click index.html).
3. If Python is installed, open a terminal in this folder and run:
   python -m http.server 8000
4. Open http://localhost:8000 in Chrome or Edge.
   Three.js is loaded from jsDelivr, so internet access is needed.
5. Use WASD / arrow keys, or touch controls on mobile. Click CHƠI NGAY.

C++:
AsteroidCore.cpp exports small helper functions. It is not automatically loaded by the browser demo.
To use as native Windows DLL, compile as a DLL and connect it to a native app or Unity plugin.
For WebAssembly, compile with Emscripten and add JS bindings/integration separately.

C#:
GameManager.cs is an optional Unity script. It is not called by the browser JavaScript build.
To use it, create a Unity 3D project, put GameManager.cs in Assets/Scripts, attach GameManager to an empty GameObject, and ensure the scene has a camera.
The browser version is the easiest one to run immediately.


PYTHON SERVER (server.py):
1. Make sure Python 3 is installed.
2. Keep server.py in the same folder as index.html, game.js, and style.css.
3. Run: python server.py
4. Open http://127.0.0.1:8000 in Chrome/Edge.
5. Press Ctrl+C in the terminal to stop the server.
