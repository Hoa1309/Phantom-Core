#!/usr/bin/env python3
"""
Asteroid Dodge 3D - small Python helper/server.

Usage:
    python server.py
Then open http://localhost:8000 in your browser.

This server serves the game files in the same folder. It does not implement the
3D game engine; the browser game is implemented in game.js with Three.js.
"""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import os
import webbrowser

HOST = "127.0.0.1"
PORT = 8000

class GameHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

def main():
    os.chdir(Path(__file__).resolve().parent)
    url = f"http://{HOST}:{PORT}"
    server = ThreadingHTTPServer((HOST, PORT), GameHandler)
    print("Asteroid Dodge 3D server is running.")
    print(f"Open this URL in Chrome or Edge: {url}")
    print("Press Ctrl+C to stop the server.")
    try:
        webbrowser.open(url)
        server.serve_forever()
    except KeyboardInterrupt:
        print("\\nServer stopped.")
    finally:
        server.server_close()

if __name__ == "__main__":
    main()
